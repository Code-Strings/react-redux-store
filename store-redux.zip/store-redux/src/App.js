import React, { useEffect, useState } from "react";
import Pizzaboard from './components/Pizzaboard'
import LoginForm from "./components/LoginForm";
import Alert from "react-bootstrap/Alert";
import { Button, Row, Col } from "react-bootstrap";
import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from "redux";
import rootReducer from "./redux/rootReducer";
import './App.css'
import thunk from "redux-thunk";

const store = createStore(rootReducer, applyMiddleware(thunk));

function App()
{
  const userLogin = {
    username: "username@gmail.com",
    password: "password123",
    loggedin: false,
    errormsg: ""
  }

  const [user, setUser] = useState({ username: "", password: "", loggedin: false });
  const [err, setError] = useState(true);

  const Login = (Credentials, err) =>
  {
    console.log(Credentials);
    console.log(userLogin);
    if (Credentials.username === userLogin.username && Credentials.password === userLogin.password)
    {
      console.log("Logged in!");
      setUser({
        username: Credentials.username,
        password: Credentials.password,
        loggedin: true
      });
      console.log(user);
    }
    else
    {
      console.log("Credentials do not match!");
      setError(false);
      console.log(err);
    }
  }

  useEffect(() =>
  {
    const loggedInUser = localStorage.getItem("user");
    if (loggedInUser)
    {
      const foundUser = (loggedInUser);
      setUser(foundUser);
    }
  }, [user]);

  const LogOut = () =>
  {
    setUser({ username: "", password: "" });
    localStorage.clear();
  }


  return (
    <div className="App">
      {(user.username !== "") ? (
        <div className="home">
          {console.log("check==> " + userLogin.loggedin)}
          <Provider store={store}>
            <Pizzaboard />
          </Provider>
          <Col><Button onClick={LogOut}>Log Out</Button></Col>
        </div>
      ) : (
        <div>
          <LoginForm Login={Login} error={err} />
          {err ? <p></p> : <Alert variant="danger" onClose={() => setError(true)} dismissible>
            <Alert.Heading>Error!</Alert.Heading>
            <p>
              enterred user name or password is wrong!
              </p>
          </Alert>}
          {console.log("check==> " + userLogin.loggedin)}
        </div>
      )}
    </div>

  )
}
export default App;