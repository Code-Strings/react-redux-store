import { combineReducers } from 'redux'
import pizzaReducer from './pizza/pizzaReducers'
import coffeeReducer from './coffee/coffeeReducer'

const rootReducer = combineReducers({
  pizza: pizzaReducer,
  coffee: coffeeReducer,
})

export default rootReducer