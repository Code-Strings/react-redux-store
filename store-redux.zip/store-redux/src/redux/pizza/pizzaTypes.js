export const BUY_PIZZA = 'BUY_PIZZA'
export const GET_PIZZA = 'GET_PIZZA'
export const ADD_PIZZA = 'ADD_PIZZA'


