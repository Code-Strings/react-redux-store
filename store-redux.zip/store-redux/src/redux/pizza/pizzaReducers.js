import uuid from "uuid/v4";
const initialPizzastate = {
  pizzaList: [
    { id: 1, pizzaName: "Paneer Pizza" },
    { id: 2, pizzaName: "Corn Pizza" },
    { id: 3, pizzaName: "Mexican mix-veg Pizza" }
  ]
};

const pizzaReducer = (state = initialPizzastate, action) =>
{
  switch (action.type)
  {
    case "GET_PIZZA":
      return {
        ...state
      };
    case "ADD_PIZZA":
      return {
        ...state,
        pizzaList: state.pizzaList.concat(action.payload)
      };
    case "BUY_PIZZA":
    //   const copyState = [...state];
    //   //Find id of object to remove
    //   const i = copyState.findIndex(x => x.id === payload.id);
    //   copyState.splice(i, 1);
    //   return [...copyState];
    // default:
    //   return state;
      return {
        ...state,
        pizzaList: state.pizzaList.filter((item) => item.id !== action.payload)
      };
    default:
      return state;
  }
};

export default pizzaReducer;