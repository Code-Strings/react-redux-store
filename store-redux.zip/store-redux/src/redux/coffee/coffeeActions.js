import { GET_COFFEE } from './coffeeTypes'

export function getCoffee()
{
  return (dispatch) =>
  {
    return dispatch({
      type: "GET_COFFEE"
    });
  };
}

export function addCoffee(data)
{
  return (dispatch) =>
  {
    return dispatch({
      type: "ADD_COFFEE",
      payload: data
    });
  };
}

export function buyCOFFEE(coffeeId)
{
  return (dispatch) =>
  {
    return dispatch({
      type: "BUY_COFFEE",
      payload:coffeeId
    });
  };
}