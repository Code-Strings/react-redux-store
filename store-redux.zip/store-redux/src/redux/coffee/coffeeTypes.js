export const BUY_COFFEE = 'BUY_COFFEE'
export const GET_COFFEE = 'GET_COFFEE'
export const ADD_COFFEE = 'ADD_COFFEE'
