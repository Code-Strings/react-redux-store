import { GET_COFFEE, ADD_COFFEE, BUY_COFFEE } from './coffeeTypes'

const initialCoffeestate = {
  coffeeList: [
    { id: 1, cofName: "Latte" },
    { id: 2, cofName: "Cappuccino" },
    { id: 3, cofName: "Espresso" }
  ]
};

const coffeeReducer = (state = initialCoffeestate, action) =>
{
  switch (action.type)
  {
    case GET_COFFEE:
      return {
        ...state
      };
    case ADD_COFFEE:
      return {
        ...state,
        coffeeList: state.coffeeList.concat(action.payload)
      };
    case BUY_COFFEE:
      return {
        ...state,
        coffeeList: state.coffeeList.filter((item) => item.id !== action.payload)
      };
    default:
      return state;
  }
};

export default coffeeReducer;