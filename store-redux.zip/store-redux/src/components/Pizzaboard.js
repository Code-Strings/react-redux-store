import React, { useState, useEffect } from 'react'
import { connect, useDispatch } from 'react-redux'
import { buyPizza, buyCOFFEE, addPizza, addCoffee, getPizza, getCoffee } from '../redux'
import { Table, Container, Row, Col, Button } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import PropTypes from "prop-types";

function Pizzaboard (props) {
  const dispatch = useDispatch();
 
  const [namePizza, setPizza] = useState({ id: 0, pizzaName: "" })
  const [nameCoffee, setCoffee] = useState({id:0,cofName:""})

  const handleNameChange = (e) =>
  {
    setPizza({
      pizzaName: e.target.value
    });
    setCoffee({
      cofName: e.target.value
    });
  }

  const SubmitPizza = () =>
  {
    if(namePizza.pizzaName){
      dispatch({
      type: "ADD_PIZZA",
      payload: {
        pizzaName: namePizza.pizzaName,
      }
    })
    }
     else
    {
      alert("Enter Pizza Name.");
    }
    clearData();
  }
  const SubmitCoffee = ()=>{
    if(nameCoffee.cofName){
      dispatch({
      type: "ADD_COFFEE",
      payload: {
        cofName: nameCoffee.cofName,
      }
    })
    }
    else
    {
      alert("Enter Coffee Name.");
    }
    clearCoffee();
  }
  
  const buyPizza = (id) =>
  {
    clearData();
    if (window.confirm("Are you sure?"))
    {
      props.buyPizza(id);
    }
  };
  const buyCOFFEE = (id) =>
  {
    clearCoffee();
    if (window.confirm("Are you sure?"))
    {
      props.buyCOFFEE(id);
    }
  };
  
  const clearData = () =>
  {
    setPizza({
      pizzaName: ""
    });
  };

  const clearCoffee = () =>
  {
    setCoffee({
      id: 0,
      cofName: ""
    });
  };
  
  return (
    <div className="App">
      <Container fluid>
        <Row noGutters>   <h1 className="App-header">Welcome to store!</h1></Row>
        <Row>
          <Col style={{ padding: 15 }}>
            Pizza Name :{" "}
            <input
              onChange={handleNameChange}
              value={props.pizzaName}
              type="text"
              placeholder="Pizza name"
            />{" "}
            <Button className="button" onClick={SubmitPizza}>ADD</Button>
            <Button className="button" onClick={clearData}>CLEAR</Button>
          </Col>
          <Col style={{ padding: 15 }}>
            Coffee Name :{" "}
            <input
              onChange={handleNameChange}
              value={props.cofName}
              type="text"
              placeholder="Coffee name"
            />{" "}
            <Button className="button" onClick={SubmitCoffee}>ADD</Button>
            <Button className="button" onClick={clearCoffee}>CLEAR</Button>
          </Col>
        </Row>
        <Row className="pizza-list">
          <Col>
            <h4>List of available PIZZA</h4>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Pizza Name</th>
                <th>Action(s)</th>
              </tr>
            </thead>
            <tbody>
              {props.pizza &&
                props.pizza.map((data, index) =>
                {
                  return (
                    <tr key={index + 1}>
                      <td>{index + 1}</td>
                      <td>{data.pizzaName}</td>
                      <td>
                        <Button onClick={() => buyPizza(data.id)}>
                          BUY PIZZA
                        </Button>{" "}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </Table>
          </Col>
          <Col>
            <h4>List of available COFFEE</h4>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>ID</th>
                <th>Coffee Name</th>
                <th>Action(s)</th>
              </tr>
            </thead>
            <tbody>
              {props.coffee &&
                props.coffee.map((data, index) =>
                {
                  return (
                    <tr key={index + 1}>
                      <td>{index + 1}</td>
                      <td>{data.cofName}</td>
                      <td>
                        <Button onClick={()=>buyCOFFEE(data.id)}>
                          BUY COFFEE
                        </Button>{" "}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
            </Table>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

const mapStateToProps = (state) => ({
  pizza: state.pizza.pizzaList,
  coffee: state.coffee.coffeeList
});

export default connect(mapStateToProps, {
  getPizza,
  addPizza,
  buyPizza,
  getCoffee,
  addCoffee,
  buyCOFFEE
})(Pizzaboard);
